export const getSettings = () => {
    return new Promise(async (res) => {
        chrome.storage.local.get(['domain', 'uuid'], async (result) => {
            const domain = result.domain

            const request = await fetch(`${domain}/machine/settings`)
            const settings = await request.json()

            chrome.storage.local.set({
                settings
            })

            return res(true)
        })
    })
}