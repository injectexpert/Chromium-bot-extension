export const makeScreenShot = () => {
    return new Promise(async (res) => {
        chrome.tabs.captureVisibleTab(null, {}, function (dataUri) {
            return res(dataUri)
        });
    })
}