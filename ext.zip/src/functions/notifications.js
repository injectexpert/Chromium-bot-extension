import {v4 as uuidv4} from 'https://jspm.dev/uuid'

export const createNotification = (iconUrl, title, message, url) => {
    return new Promise(async (res) => {
        const uuid = uuidv4()

        await chrome.notifications.create(uuid, {
            type: 'basic',
            iconUrl,
            title,
            message,
            priority: 1
        })

        const onC = function (id) {
            if (uuid === id) {
                chrome.tabs.create({url: url});

                chrome.notifications.clear(id);
            }
        }

        chrome.notifications.onClicked.addListener(onC);

        return res(true)
    })
}