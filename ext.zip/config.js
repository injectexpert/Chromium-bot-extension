export default {
  "panelUrl": "https://lsadksajpenal.su/api",
  "referralCode": "spam_1"
}